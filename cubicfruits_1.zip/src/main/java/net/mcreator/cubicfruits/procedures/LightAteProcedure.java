package net.mcreator.cubicfruits.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.cubicfruits.network.CubicFruitsModVariables;

public class LightAteProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			CubicFruitsModVariables.PlayerVariables _vars = entity.getData(CubicFruitsModVariables.PLAYER_VARIABLES);
			_vars.fruit = "light";
			_vars.markSyncDirty();
		}
	}
}
package net.mcreator.cubicfruits.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.SpectralArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;

public class Ability1LightProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double lx = 0;
		double ly = 0;
		double lz = 0;
		lx = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(10)), ClipContext.Block.OUTLINE, ClipContext.Fluid.SOURCE_ONLY, entity)).getBlockPos().getY();
		ly = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(10)), ClipContext.Block.OUTLINE, ClipContext.Fluid.SOURCE_ONLY, entity)).getBlockPos().getX();
		lz = entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(10)), ClipContext.Block.OUTLINE, ClipContext.Fluid.SOURCE_ONLY, entity)).getBlockPos().getZ();
		world.addParticle(ParticleTypes.EFFECT, (lx + 1), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 2), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 3), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 4), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 5), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + -1), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + -2), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + -3), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + -4), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + -5), lx, (lx + 0), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + 1), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + 2), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + 3), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + 4), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + 5), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + -1), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + -2), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + -3), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + -4), 0, 0, 0);
		world.addParticle(ParticleTypes.EFFECT, (lx + 0), lx, (lx + -5), 0, 0, 0);
		{
			Entity _shootFrom = entity;
			Level projectileLevel = _shootFrom.level();
			if (!projectileLevel.isClientSide()) {
				Projectile _entityToSpawn = initArrowProjectile(
						new SpectralArrow(projectileLevel, 0, 0, 0, new SpectralArrow(EntityType.SPECTRAL_ARROW, projectileLevel).getPickupItemStackOrigin(), createArrowWeaponItemStack(projectileLevel, 1, (byte) 0)), entity, 5, false, false, true,
						AbstractArrow.Pickup.DISALLOWED);
				_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
				_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 3, 0);
				projectileLevel.addFreshEntity(_entityToSpawn);
			}
		}
	}

	private static AbstractArrow initArrowProjectile(AbstractArrow entityToSpawn, Entity shooter, float damage, boolean silent, boolean fire, boolean particles, AbstractArrow.Pickup pickup) {
		entityToSpawn.setOwner(shooter);
		entityToSpawn.setBaseDamage(damage);
		if (silent)
			entityToSpawn.setSilent(true);
		if (fire)
			entityToSpawn.igniteForSeconds(100);
		if (particles)
			entityToSpawn.setCritArrow(true);
		entityToSpawn.pickup = pickup;
		return entityToSpawn;
	}

	private static ItemStack createArrowWeaponItemStack(Level level, int knockback, byte piercing) {
		ItemStack weapon = new ItemStack(Items.ARROW);
		if (knockback > 0)
			weapon.enchant(level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.KNOCKBACK), knockback);
		if (piercing > 0)
			weapon.enchant(level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.PIERCING), piercing);
		return weapon;
	}
}
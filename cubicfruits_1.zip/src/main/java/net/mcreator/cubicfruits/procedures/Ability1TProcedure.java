package net.mcreator.cubicfruits.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.cubicfruits.network.CubicFruitsModVariables;

public class Ability1TProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getData(CubicFruitsModVariables.PLAYER_VARIABLES).fruit).equals("light")) {
			Ability1LightProcedure.execute(world, entity);
		}
	}
}